# track1
CUDA_VISIBLE_DEVICES=0 python code/train.py -opt realsr_options/ep420_track1_c_grad_lap_sam_vgg19_l1.yml


# track2
CUDA_VISIBLE_DEVICES=0 python code/train.py -opt realsr_options/ker_ep175_track2_c_grad_lap_sam_vgg19_l1.yml
